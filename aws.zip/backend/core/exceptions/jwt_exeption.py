class JWTException(Exception):
    pass